using System;
using System.Collections.Generic;
using Microsoft.Data.Entity.Migrations;
using Microsoft.Data.Entity.Metadata;

namespace LojaWeb.Migrations
{
    public partial class addCarrinho : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_Produto_CategoriaProduto_CategoriaID", table: "Produto");
            migrationBuilder.CreateTable(
                name: "Carrinho",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    PrecoFinal = table.Column<double>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Carrinho", x => x.Id);
                });
            migrationBuilder.AddColumn<int>(
                name: "CarrinhoId",
                table: "Produto",
                nullable: true);
            migrationBuilder.AddForeignKey(
                name: "FK_Produto_Carrinho_CarrinhoId",
                table: "Produto",
                column: "CarrinhoId",
                principalTable: "Carrinho",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_Produto_CategoriaProduto_CategoriaID",
                table: "Produto",
                column: "CategoriaID",
                principalTable: "CategoriaProduto",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_Produto_Carrinho_CarrinhoId", table: "Produto");
            migrationBuilder.DropForeignKey(name: "FK_Produto_CategoriaProduto_CategoriaID", table: "Produto");
            migrationBuilder.DropColumn(name: "CarrinhoId", table: "Produto");
            migrationBuilder.DropTable("Carrinho");
            migrationBuilder.AddForeignKey(
                name: "FK_Produto_CategoriaProduto_CategoriaID",
                table: "Produto",
                column: "CategoriaID",
                principalTable: "CategoriaProduto",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
