using System;
using System.Collections.Generic;
using Microsoft.Data.Entity.Migrations;

namespace LojaWeb.Migrations
{
    public partial class addItemCarrinho : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_Produto_Carrinho_CarrinhoId", table: "Produto");
            migrationBuilder.DropForeignKey(name: "FK_Produto_CategoriaProduto_CategoriaID", table: "Produto");
            migrationBuilder.DropColumn(name: "CarrinhoId", table: "Produto");
            migrationBuilder.CreateTable(
                name: "ItemCarrinho",
                columns: table => new
                {
                    IdCarrinho = table.Column<int>(nullable: false),
                    IdProduto = table.Column<int>(nullable: false),
                    CarrinhoId = table.Column<int>(nullable: true),
                    Preco = table.Column<double>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ItemCarrinho", x => new { x.IdCarrinho, x.IdProduto });
                    table.ForeignKey(
                        name: "FK_ItemCarrinho_Carrinho_CarrinhoId",
                        column: x => x.CarrinhoId,
                        principalTable: "Carrinho",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.AddColumn<int>(
                name: "IdUser",
                table: "Carrinho",
                nullable: false,
                defaultValue: 0);
            migrationBuilder.AddForeignKey(
                name: "FK_Produto_CategoriaProduto_CategoriaID",
                table: "Produto",
                column: "CategoriaID",
                principalTable: "CategoriaProduto",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_Produto_CategoriaProduto_CategoriaID", table: "Produto");
            migrationBuilder.DropColumn(name: "IdUser", table: "Carrinho");
            migrationBuilder.DropTable("ItemCarrinho");
            migrationBuilder.AddColumn<int>(
                name: "CarrinhoId",
                table: "Produto",
                nullable: true);
            migrationBuilder.AddForeignKey(
                name: "FK_Produto_Carrinho_CarrinhoId",
                table: "Produto",
                column: "CarrinhoId",
                principalTable: "Carrinho",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_Produto_CategoriaProduto_CategoriaID",
                table: "Produto",
                column: "CategoriaID",
                principalTable: "CategoriaProduto",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
