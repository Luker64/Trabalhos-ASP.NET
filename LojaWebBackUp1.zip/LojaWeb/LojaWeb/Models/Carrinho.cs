﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LojaWeb.Models
{
    public class Carrinho
    {
        public int Id { get; set; }
        public double PrecoFinal { get; set; }
        public int IdUser { get; set; }
        public IList<ItemCarrinho> itemCarrinhos { get; set; }
    }
}