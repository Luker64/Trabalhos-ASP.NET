﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LojaWeb.Models;

namespace LojaWeb.DAO{
    public class CarrinhoDAO {
        private EntidadeContext context;

        public CarrinhoDAO()
        {
            context = new EntidadeContext();
        }

        public bool Login(Usuario user)
        {
            UsuarioDAO udao = new UsuarioDAO();
            bool c = false;
            c = udao.CheckLogin(user);
            return c;
        }

        public void SetUserLog(Usuario user)
        {
            UserLogado.Id = user.Id;
            UserLogado.Nome = user.Nome;
            UserLogado.Senha = user.Senha;
        }

        public Carrinho CriaCarrinho()
        {
            Carrinho c = new Carrinho();
            return c;
        }

        public void AdicionarProd(Produto prod)
        {
            //if () {
            //    Carrinho c = CriaCarrinho();
            //}
        }
    }      
}