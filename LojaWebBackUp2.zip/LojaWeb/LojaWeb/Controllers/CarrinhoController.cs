﻿using LojaWeb.DAO;
using LojaWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LojaWeb.Controllers
{
    public class CarrinhoController : Controller
    {
        // GET: Carrinho
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        public ActionResult Escolher(Usuario user)
        {
            CarrinhoDAO dao = new CarrinhoDAO();
            if((user.Nome == null) && (user.Senha == null))
            {
                user.Id = UserLogado.Id;
                user.Nome = UserLogado.Nome;
                user.Senha = UserLogado.Senha;
            }
            bool b = dao.Login(user);
            if (b)
            {
                dao.SetUserLog(user);
                return RedirectToAction("Carrinho");
            }
            return RedirectToAction("Login");
        }

        public ActionResult Carrinho()
        {
            ProdutoDAO pdao = new ProdutoDAO();
            IList<Produto> prods = pdao.ListarProduto();
            ViewBag.produts = prods;
            return View();
        }

        public ActionResult Adicionar()
        {
            CarrinhoDAO dao = new CarrinhoDAO();
            //dao.AdicionarProd();
            return RedirectToAction("Carrinho");
        }
    }
}